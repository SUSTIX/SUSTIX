window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "8mLCPikrgfBExYfwcXUkspLSEdc7EEOyR0aIRhwU",
    "createdAt" : "2019-03-10T23:13:58.946Z",
    "lastSeenAt" : "2019-05-30T13:23:54.122Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "CXr3DGZmkwBZPokNao4rIbksBJKu6cGJIE5Z8Esp",
    "createdAt" : "2019-03-10T23:15:06.012Z",
    "lastSeenAt" : "2019-05-30T13:37:20.259Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "odZN6QNodYWjTCj4gjApMlH56Ntj0EsiFwUfWBVg",
    "createdAt" : "2019-05-03T02:46:48.851Z",
    "lastSeenAt" : "2019-07-03T16:43:53.378Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "258901",
    "token" : "sVt8I4essukN2IXIb1GsUOTzPJoEw5t8dnkTLNLf",
    "createdAt" : "2019-06-24T23:48:53.832Z",
    "lastSeenAt" : "2019-09-02T22:47:20.809Z",
    "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "3iIxyCVQQg6VxrvWQ8SOSiPIO6oZMWVTRd2xXePN",
    "createdAt" : "2019-07-08T09:21:57.392Z",
    "lastSeenAt" : "2019-09-03T03:17:08.909Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
} ]