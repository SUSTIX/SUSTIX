window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceVersion" : "8.11.0-release.00",
      "deviceType" : "Twitter for Android",
      "token" : "e3f-pTanttE:APA91bEUINqdJHcyKaYGkN0rQW879eT5z1sLNtpk-DN4JpoQzlJRpJ0He1TevASJ8YwT-DilbgIjdvprUU1DdyjEC1hXC4d2t91tM5IMMZ9qlk9bg4r0rzO3O66ULJZs3EkVe9eXYCL3",
      "updatedDate" : "2019.09.04",
      "createdDate" : "2019.09.02"
    }
  }
} ]