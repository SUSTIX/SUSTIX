window.YTD.lists_created.part0 = [ {
  "userListInfo" : {
    "urls" : [ "https://twitter.com/Downnotout2/lists/new", "https://twitter.com/Downnotout2/lists/d" ]
  }
} ]