window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "Words help me figure out who I am and how I feel about everything.",
      "website" : "",
      "location" : ""
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1171177667086958594/dPfBYGsG.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1134088040538939392/1567465053"
  }
} ]