window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : ""
    },
    "name" : "Twitter for Android",
    "description" : "Twitter for Android",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2019-09-02T22:47:20.000Z",
    "id" : "258901"
  }
} ]