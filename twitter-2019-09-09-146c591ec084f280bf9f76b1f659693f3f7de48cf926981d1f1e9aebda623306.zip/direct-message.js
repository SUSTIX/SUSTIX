window.YTD.direct_message.part0 = [ {
  "dmConversation" : {
    "conversationId" : "4852289459-1134088040538939392",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1134088040538939392",
        "text" : "Thanks for the follow! If you enjoy our Tweets, please consider SUBSCRIBING to our YouTube Channel as well. It would be much appreciated! https://t.co/D95w7Bo4dY",
        "mediaUrls" : [ ],
        "senderId" : "4852289459",
        "id" : "1134862999305560070",
        "createdAt" : "2019-06-01T16:43:18.474Z"
      }
    } ]
  }
} ]