window.YTD.ad_mobile_conversions_unattributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-11 16:29:00"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-11 17:35:41"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-11 10:00:13"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-14 23:27:33"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-14 23:28:02"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-26 12:00:14"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "install",
          "applicationName" : "Spotify: Discover new music, podcasts, and songs",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-26 20:09:27"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-29 12:41:15"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-30 02:28:03"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-30 13:05:21"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Spotify: Discover new music, podcasts, and songs",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-30 19:25:25"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Spotify: Discover new music, podcasts, and songs",
          "conversionValue" : "0",
          "conversionTime" : "2019-09-01 17:03:28"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Spotify: Discover new music, podcasts, and songs",
          "conversionValue" : "0",
          "conversionTime" : "2019-09-01 13:14:07"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-09-01 13:01:55"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Spotify: Discover new music, podcasts, and songs",
          "conversionValue" : "0",
          "conversionTime" : "2019-09-01 19:28:12"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-09-01 12:51:29"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-15 14:03:34"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-16 00:34:37"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-16 15:05:41"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-20 23:21:48"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-23 01:11:47"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-24 01:15:46"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-24 19:04:19"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Kijiji: Buy, Sell and Save on Local Deals",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-25 09:52:42"
        }, {
          "mobilePlatform" : "Android",
          "conversionEvent" : "re_engage",
          "applicationName" : "Deepstash - Self Improvement, Motivation & Care",
          "conversionValue" : "0",
          "conversionTime" : "2019-08-25 15:34:30"
        } ]
      }
    }
  }
} ]