window.YTD.following.part0 = [ {
  "following" : {
    "accountId" : "13298072",
    "userLink" : "https://twitter.com/intent/user?user_id=13298072"
  }
}, {
  "following" : {
    "accountId" : "34743251",
    "userLink" : "https://twitter.com/intent/user?user_id=34743251"
  }
}, {
  "following" : {
    "accountId" : "3429950987",
    "userLink" : "https://twitter.com/intent/user?user_id=3429950987"
  }
}, {
  "following" : {
    "accountId" : "3511430425",
    "userLink" : "https://twitter.com/intent/user?user_id=3511430425"
  }
}, {
  "following" : {
    "accountId" : "116994659",
    "userLink" : "https://twitter.com/intent/user?user_id=116994659"
  }
}, {
  "following" : {
    "accountId" : "2228878592",
    "userLink" : "https://twitter.com/intent/user?user_id=2228878592"
  }
}, {
  "following" : {
    "accountId" : "216776631",
    "userLink" : "https://twitter.com/intent/user?user_id=216776631"
  }
}, {
  "following" : {
    "accountId" : "2241150253",
    "userLink" : "https://twitter.com/intent/user?user_id=2241150253"
  }
}, {
  "following" : {
    "accountId" : "44196397",
    "userLink" : "https://twitter.com/intent/user?user_id=44196397"
  }
} ]