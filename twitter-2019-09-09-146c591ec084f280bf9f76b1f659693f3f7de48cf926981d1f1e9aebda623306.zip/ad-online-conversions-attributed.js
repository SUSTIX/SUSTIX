window.YTD.ad_online_conversions_attributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "SiteVisit",
          "eventType" : "pageview",
          "conversionPlatform" : "Mobile",
          "conversionUrl" : "https://www.canadiantire.ca/en/sports-rec/boating-water-sports/canoes-kayaks-paddle-boards/kayaks.html",
          "advertiserInfo" : {
            "advertiserName" : "Canadian Tire",
            "screenName" : "@CanadianTire"
          },
          "conversionValue" : "0",
          "conversionTime" : "2019-06-23 21:05:01",
          "additionalParameters" : { }
        } ]
      }
    }
  }
} ]