window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "English",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "ABC News",
        "isDisabled" : false
      }, {
        "name" : "Albert Einstein",
        "isDisabled" : false
      }, {
        "name" : "Amazon",
        "isDisabled" : false
      }, {
        "name" : "Andrew Yang",
        "isDisabled" : false
      }, {
        "name" : "Aparna Nancherla",
        "isDisabled" : false
      }, {
        "name" : "Auto",
        "isDisabled" : false
      }, {
        "name" : "Barack Obama",
        "isDisabled" : false
      }, {
        "name" : "Baseball",
        "isDisabled" : false
      }, {
        "name" : "Basketball",
        "isDisabled" : false
      }, {
        "name" : "Beer",
        "isDisabled" : false
      }, {
        "name" : "Bernie Sanders",
        "isDisabled" : false
      }, {
        "name" : "Betsy DeVos",
        "isDisabled" : false
      }, {
        "name" : "Bill Clinton",
        "isDisabled" : false
      }, {
        "name" : "Bitcoin Cryptocurrency",
        "isDisabled" : false
      }, {
        "name" : "BloodPop",
        "isDisabled" : false
      }, {
        "name" : "Brazil - Soccer",
        "isDisabled" : false
      }, {
        "name" : "Breaking News",
        "isDisabled" : false
      }, {
        "name" : "Business & Finance",
        "isDisabled" : false
      }, {
        "name" : "Business & Finance",
        "isDisabled" : false
      }, {
        "name" : "Business Leaders",
        "isDisabled" : false
      }, {
        "name" : "CNN",
        "isDisabled" : false
      }, {
        "name" : "Canadian News and Media",
        "isDisabled" : false
      }, {
        "name" : "Car culture",
        "isDisabled" : false
      }, {
        "name" : "Carl Quintanilla",
        "isDisabled" : false
      }, {
        "name" : "Celebrities",
        "isDisabled" : false
      }, {
        "name" : "Celebrity",
        "isDisabled" : false
      }, {
        "name" : "Chanel",
        "isDisabled" : false
      }, {
        "name" : "Chess",
        "isDisabled" : false
      }, {
        "name" : "Chevrolet",
        "isDisabled" : false
      }, {
        "name" : "Chevrolet - Corvette",
        "isDisabled" : false
      }, {
        "name" : "Chris Cillizza",
        "isDisabled" : false
      }, {
        "name" : "Chuck Todd",
        "isDisabled" : false
      }, {
        "name" : "Cocktails and beer",
        "isDisabled" : false
      }, {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Computer gaming",
        "isDisabled" : false
      }, {
        "name" : "Cory Booker",
        "isDisabled" : false
      }, {
        "name" : "Crime",
        "isDisabled" : false
      }, {
        "name" : "Cryptocurrencies",
        "isDisabled" : false
      }, {
        "name" : "Debra Messing",
        "isDisabled" : false
      }, {
        "name" : "Design",
        "isDisabled" : false
      }, {
        "name" : "Digital Creators & Channels",
        "isDisabled" : false
      }, {
        "name" : "Dodge",
        "isDisabled" : false
      }, {
        "name" : "Dodge - Ram",
        "isDisabled" : false
      }, {
        "name" : "Dogs",
        "isDisabled" : false
      }, {
        "name" : "Donald Trump",
        "isDisabled" : false
      }, {
        "name" : "Education System in the United States",
        "isDisabled" : false
      }, {
        "name" : "Education around the world",
        "isDisabled" : false
      }, {
        "name" : "Elon Musk",
        "isDisabled" : false
      }, {
        "name" : "Entertainment",
        "isDisabled" : false
      }, {
        "name" : "Everyday Astronaut",
        "isDisabled" : false
      }, {
        "name" : "Exercise and fitness",
        "isDisabled" : false
      }, {
        "name" : "Facebook",
        "isDisabled" : false
      }, {
        "name" : "Fashion",
        "isDisabled" : false
      }, {
        "name" : "Fast food",
        "isDisabled" : false
      }, {
        "name" : "Final Fantasy VII",
        "isDisabled" : false
      }, {
        "name" : "Fitness & Wellness",
        "isDisabled" : false
      }, {
        "name" : "Food",
        "isDisabled" : false
      }, {
        "name" : "Ford EVs",
        "isDisabled" : false
      }, {
        "name" : "Ford Latino",
        "isDisabled" : false
      }, {
        "name" : "GM Latino",
        "isDisabled" : false
      }, {
        "name" : "Games",
        "isDisabled" : false
      }, {
        "name" : "Gaming",
        "isDisabled" : false
      }, {
        "name" : "Gears 5",
        "isDisabled" : false
      }, {
        "name" : "Gears of War",
        "isDisabled" : false
      }, {
        "name" : "General Motors",
        "isDisabled" : false
      }, {
        "name" : "Global Economy",
        "isDisabled" : false
      }, {
        "name" : "Global Environmental Issues",
        "isDisabled" : false
      }, {
        "name" : "Global Security and Terrorism",
        "isDisabled" : false
      }, {
        "name" : "Golf",
        "isDisabled" : false
      }, {
        "name" : "Golf",
        "isDisabled" : false
      }, {
        "name" : "Google ",
        "isDisabled" : false
      }, {
        "name" : "Google Chrome",
        "isDisabled" : false
      }, {
        "name" : "Gov Officials & Agencies",
        "isDisabled" : false
      }, {
        "name" : "Grimes",
        "isDisabled" : false
      }, {
        "name" : "Gun Laws in the United States",
        "isDisabled" : false
      }, {
        "name" : "History",
        "isDisabled" : false
      }, {
        "name" : "Hobbies and interests",
        "isDisabled" : false
      }, {
        "name" : "Hotel/Motel",
        "isDisabled" : false
      }, {
        "name" : "Immigration Policies Worldwide",
        "isDisabled" : false
      }, {
        "name" : "Insurance",
        "isDisabled" : false
      }, {
        "name" : "Insurance",
        "isDisabled" : false
      }, {
        "name" : "Intel",
        "isDisabled" : false
      }, {
        "name" : "Jared Huffman",
        "isDisabled" : false
      }, {
        "name" : "Joe Biden",
        "isDisabled" : false
      }, {
        "name" : "Joe Rogan",
        "isDisabled" : false
      }, {
        "name" : "Joel Heyman",
        "isDisabled" : false
      }, {
        "name" : "Joni Ernst",
        "isDisabled" : false
      }, {
        "name" : "Judd Apatow",
        "isDisabled" : false
      }, {
        "name" : "Kroger",
        "isDisabled" : false
      }, {
        "name" : "LeBron James",
        "isDisabled" : false
      }, {
        "name" : "Lenovo",
        "isDisabled" : false
      }, {
        "name" : "Los Angeles Times",
        "isDisabled" : false
      }, {
        "name" : "Mara Wilson",
        "isDisabled" : false
      }, {
        "name" : "Marques Brownlee",
        "isDisabled" : false
      }, {
        "name" : "Marvel Universe",
        "isDisabled" : false
      }, {
        "name" : "Men's Golf",
        "isDisabled" : false
      }, {
        "name" : "Movies",
        "isDisabled" : false
      }, {
        "name" : "Movies / Tv / Radio",
        "isDisabled" : false
      }, {
        "name" : "Multimedia Franchise",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music and radio",
        "isDisabled" : false
      }, {
        "name" : "Music festivals and concerts",
        "isDisabled" : false
      }, {
        "name" : "NASA",
        "isDisabled" : false
      }, {
        "name" : "National Rifle Association",
        "isDisabled" : false
      }, {
        "name" : "News / Politics",
        "isDisabled" : false
      }, {
        "name" : "Online gaming",
        "isDisabled" : false
      }, {
        "name" : "Paul Rudd",
        "isDisabled" : false
      }, {
        "name" : "PewDiePie",
        "isDisabled" : false
      }, {
        "name" : "Physics",
        "isDisabled" : false
      }, {
        "name" : "Pie",
        "isDisabled" : false
      }, {
        "name" : "Podcasts",
        "isDisabled" : false
      }, {
        "name" : "Political Body",
        "isDisabled" : false
      }, {
        "name" : "Political Figures",
        "isDisabled" : false
      }, {
        "name" : "Political Issues",
        "isDisabled" : false
      }, {
        "name" : "Politics",
        "isDisabled" : false
      }, {
        "name" : "Pop Culture",
        "isDisabled" : false
      }, {
        "name" : "Porsche",
        "isDisabled" : false
      }, {
        "name" : "RAM",
        "isDisabled" : false
      }, {
        "name" : "Retail",
        "isDisabled" : false
      }, {
        "name" : "Ricky Gervais",
        "isDisabled" : false
      }, {
        "name" : "Ryan Saavedra",
        "isDisabled" : false
      }, {
        "name" : "Sci-fi and Fantasy Films",
        "isDisabled" : false
      }, {
        "name" : "Sci-fi and fantasy",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science News",
        "isDisabled" : false
      }, {
        "name" : "Science News",
        "isDisabled" : false
      }, {
        "name" : "Shoes",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "South America - Soccer",
        "isDisabled" : false
      }, {
        "name" : "Space News",
        "isDisabled" : false
      }, {
        "name" : "Space Science",
        "isDisabled" : false
      }, {
        "name" : "Space and astronomy",
        "isDisabled" : false
      }, {
        "name" : "SpaceX",
        "isDisabled" : false
      }, {
        "name" : "Sporting events",
        "isDisabled" : false
      }, {
        "name" : "Sporting goods",
        "isDisabled" : false
      }, {
        "name" : "Sports",
        "isDisabled" : false
      }, {
        "name" : "Sports Figures",
        "isDisabled" : false
      }, {
        "name" : "Sports news",
        "isDisabled" : false
      }, {
        "name" : "Sunglasses",
        "isDisabled" : false
      }, {
        "name" : "Syrian War",
        "isDisabled" : false
      }, {
        "name" : "Tabletop Gaming",
        "isDisabled" : false
      }, {
        "name" : "Tech news",
        "isDisabled" : false
      }, {
        "name" : "Technology and computing",
        "isDisabled" : false
      }, {
        "name" : "Terminator: Dark Fate",
        "isDisabled" : false
      }, {
        "name" : "Tesla - Model 3",
        "isDisabled" : false
      }, {
        "name" : "Tesla Motors",
        "isDisabled" : false
      }, {
        "name" : "The Dolan Twins",
        "isDisabled" : false
      }, {
        "name" : "The New York Times",
        "isDisabled" : false
      }, {
        "name" : "The Washington Post",
        "isDisabled" : false
      }, {
        "name" : "The White House",
        "isDisabled" : false
      }, {
        "name" : "Toronto Blue Jays",
        "isDisabled" : false
      }, {
        "name" : "Travel",
        "isDisabled" : false
      }, {
        "name" : "Travel To: Asia",
        "isDisabled" : false
      }, {
        "name" : "Travel To: Canada",
        "isDisabled" : false
      }, {
        "name" : "Travel To: China",
        "isDisabled" : false
      }, {
        "name" : "Travel to: North America",
        "isDisabled" : false
      }, {
        "name" : "Twitter",
        "isDisabled" : false
      }, {
        "name" : "United States Cabinet",
        "isDisabled" : false
      }, {
        "name" : "United States Healthcare System",
        "isDisabled" : false
      }, {
        "name" : "Vala Afshar",
        "isDisabled" : false
      }, {
        "name" : "Video Games",
        "isDisabled" : false
      }, {
        "name" : "Walmart",
        "isDisabled" : false
      }, {
        "name" : "Water",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Whole Foods",
        "isDisabled" : false
      }, {
        "name" : "Wolf Blitzer",
        "isDisabled" : false
      }, {
        "name" : "Yoga",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "0",
        "advertisers" : [ ]
      },
      "shows" : [ "Barclays Premier League Football", "Bill Nye Saves the World (Netflix)", "Black Mirror (Netflix)", "Bob Esponja", "Chernobyl", "College Football", "College GameDay", "College GameDay (College Football)", "Full Frontal With Samantha Bee", "Game of Thrones", "Happy Valley", "Homecoming (Amazon)", "La reine des neiges", "Live: College Football", "Live: NBA Basketball", "Looney Tunes", "MLB Baseball", "NBA Basketball", "NOS4A2", "One Punch Man", "Philip K. Dick's Electric Dreams (Amazon)", "Red Dwarf", "Sesame Street", "SpongeBob SquarePants", "Terminator: Dark Fate", "The Adventures of Rocky and Bullwinkle (Amazon)", "The Avengers: Endgame", "The Dark Tower", "The Voice : la plus belle voix", "Toy Story 4", "UEFA Champions League Football", "UEFA Champions League: TSG 1899 Hoffenheim-Liverpool FC", "ワンパンマン" ]
    },
    "locationHistory" : [ ],
    "inferredAgeInfo" : {
      "age" : [ ],
      "birthDate" : ""
    }
  }
} ]