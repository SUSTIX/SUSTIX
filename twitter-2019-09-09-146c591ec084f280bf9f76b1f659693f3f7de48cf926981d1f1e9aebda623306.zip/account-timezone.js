window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "1134088040538939392"
  }
} ]