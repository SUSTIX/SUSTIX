window.YTD.direct_message_headers.part0 = [ {
  "dmConversation" : {
    "conversationId" : "4852289459-1134088040538939392",
    "messages" : [ {
      "messageCreate" : {
        "id" : "1134862999305560070",
        "senderId" : "4852289459",
        "recipientId" : "1134088040538939392",
        "createdAt" : "2019-06-01T16:43:18.474Z"
      }
    } ]
  }
} ]