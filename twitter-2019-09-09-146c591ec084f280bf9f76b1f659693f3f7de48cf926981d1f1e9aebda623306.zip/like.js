window.YTD.like.part0 = [ {
  "like" : {
    "tweetId" : "1142200795523239937",
    "fullText" : "reality:\n1 Ford F-150 will emit more CO2 and polluting gases into the atmosphere in 1 day of driving than 10 million Teslas over their entire 25yr lifetime.\n\n$tsla $tslaq",
    "expandedUrl" : "https://twitter.com/i/web/status/1142200795523239937"
  }
}, {
  "like" : {
    "tweetId" : "1135948230485843969",
    "fullText" : "“We accept their findings including that what happened amounts to genocide,” said @JustinTrudeau about #MMIWG report. “There are many debates ongoing around words... Our focus as a country, as leaders, as citizens must be on the steps we take to put an end to this situation.” https://t.co/Nmvs5KYfy6",
    "expandedUrl" : "https://twitter.com/i/web/status/1135948230485843969"
  }
}, {
  "like" : {
    "tweetId" : "1142111056665423873",
    "fullText" : "So this happened... https://t.co/j6LTsaLSmj",
    "expandedUrl" : "https://twitter.com/i/web/status/1142111056665423873"
  }
}, {
  "like" : {
    "tweetId" : "1141501481901645825",
    "fullText" : "Check it out. LightSail 2 is loaded on its Falcon Heavy rocket. If all goes well, we launch on Monday! https://t.co/CshapqTBTu",
    "expandedUrl" : "https://twitter.com/i/web/status/1141501481901645825"
  }
}, {
  "like" : {
    "tweetId" : "1141830388043509760",
    "fullText" : "Angry People: Boeing cannot call it “AutoPilot” until pilots are all fired, the plane flies completely on its own, and Boeing is liable for all crashes!\n\nPilots: Wait, what?\n\nBoeing: Wait, what?!",
    "expandedUrl" : "https://twitter.com/i/web/status/1141830388043509760"
  }
}, {
  "like" : {
    "tweetId" : "1169110983165583362",
    "fullText" : "“I was originally supposed to become an engineer but the thought of having to expend my creative energy on things that make practical everyday life even more refined, with a loathsome capital gain as the goal, was unbearable to me.”\n\n― Albert Einstein",
    "expandedUrl" : "https://twitter.com/i/web/status/1169110983165583362"
  }
}, {
  "like" : {
    "tweetId" : "1169200652989452290",
    "fullText" : "@justpaulinelol @elonmusk @nichegamer https://t.co/U0DAMe8hXd",
    "expandedUrl" : "https://twitter.com/i/web/status/1169200652989452290"
  }
}, {
  "like" : {
    "tweetId" : "1136399060875784192",
    "fullText" : "@warnerthuston Catholic Church: \"Give them to me until they are seven, and they are mine forever.\"",
    "expandedUrl" : "https://twitter.com/i/web/status/1136399060875784192"
  }
}, {
  "like" : {
    "tweetId" : "1144695991070842880",
    "fullText" : "@KKublai5 What are your GM estimates then :D? https://t.co/vlA3V8gyLS",
    "expandedUrl" : "https://twitter.com/i/web/status/1144695991070842880"
  }
}, {
  "like" : {
    "tweetId" : "1141949883458285569",
    "fullText" : "@universal_sci well i guess it's time for me 2 stop taking vitamin d",
    "expandedUrl" : "https://twitter.com/i/web/status/1141949883458285569"
  }
}, {
  "like" : {
    "tweetId" : "1167520720236232709",
    "fullText" : "Haha actually true https://t.co/VNB822fpPT",
    "expandedUrl" : "https://twitter.com/i/web/status/1167520720236232709"
  }
}, {
  "like" : {
    "tweetId" : "1141536342041669632",
    "fullText" : "Square Enix has shared a bunch of new screenshots for the Final Fantasy VII Remake, giving a closer look at Midgar, Aerith in battle, and even Shinra HQ! More screens here: https://t.co/nHfPTtp84b https://t.co/PuxlpfKEoN",
    "expandedUrl" : "https://twitter.com/i/web/status/1141536342041669632"
  }
}, {
  "like" : {
    "tweetId" : "1141395064599580674",
    "fullText" : "Agree.  There's a lot of fake GOP outrage from folks who have no problem with warehousing thousands of innocent, desperate people in barbed-wire enclosures that look and function like concentration camps. Can we please talk about that? https://t.co/ywP00PEZPk",
    "expandedUrl" : "https://twitter.com/i/web/status/1141395064599580674"
  }
}, {
  "like" : {
    "tweetId" : "1168759884541808640",
    "fullText" : "“All we know about the new economic world tells us that nations which train engineers will prevail over those which train lawyers. No nation has ever sued its way to greatness.”\n\n― Richard Lamm",
    "expandedUrl" : "https://twitter.com/i/web/status/1168759884541808640"
  }
}, {
  "like" : {
    "tweetId" : "1141515462192373761",
    "fullText" : "Guy just drove by me in a very new Mustang convertible... he is very proud but all I hear is noise pollution. Buy a BEV and you will soon realize we are living in an overly polluted world.",
    "expandedUrl" : "https://twitter.com/i/web/status/1141515462192373761"
  }
}, {
  "like" : {
    "tweetId" : "1141070100461543424",
    "fullText" : "When I #bothsides, I'm not suggesting a false equivalence. I'm suggesting we frame our differences with an appreciation of our similarities. I'm suggesting that the thing we accuse the other side of doing isn't the real issue, because our side does it too.",
    "expandedUrl" : "https://twitter.com/i/web/status/1141070100461543424"
  }
}, {
  "like" : {
    "tweetId" : "1136060264200097792",
    "fullText" : "You don't need to know everything. You don't really need a formal background in this or that -- though it helps. You don't even need a PhD.\n\nYou do, however, need to be constantly learning. Be curious. Read books. Don't be \"too busy\" to learn, or otherwise proud of your ignorance",
    "expandedUrl" : "https://twitter.com/i/web/status/1136060264200097792"
  }
}, {
  "like" : {
    "tweetId" : "1141517211477188608",
    "fullText" : "Most of these kids will be damaged for life. Shame on you @chucktodd.  Lives are being destroyed. https://t.co/EDPwm5IbNn",
    "expandedUrl" : "https://twitter.com/i/web/status/1141517211477188608"
  }
}, {
  "like" : {
    "tweetId" : "1169477682763091970",
    "fullText" : "“The problem in this business isn’t to keep people from stealing your ideas; it's making them steal your ideas!”\n\n― Howard Aiken",
    "expandedUrl" : "https://twitter.com/i/web/status/1169477682763091970"
  }
}, {
  "like" : {
    "tweetId" : "1144704417247191044",
    "fullText" : "@RandyVegetables https://t.co/nYA3UWjvga",
    "expandedUrl" : "https://twitter.com/i/web/status/1144704417247191044"
  }
}, {
  "like" : {
    "tweetId" : "1169479310052384774",
    "fullText" : "@engineers_feed Except when businesses steal ideas and patent them against societies interests, i.e. so they can prevent technology from being shared as more lucrative to provide treatment than cure or disposable good over long term use good. So messed up&amp; inefficient, also prevents synergies☹️.",
    "expandedUrl" : "https://twitter.com/i/web/status/1169479310052384774"
  }
}, {
  "like" : {
    "tweetId" : "1167928516106575873",
    "fullText" : "Greg the hero we need, not the one we deserve.\n\nPS All hail the Lord Elon!! https://t.co/M9pPRgBda9",
    "expandedUrl" : "https://twitter.com/i/web/status/1167928516106575873"
  }
}, {
  "like" : {
    "tweetId" : "1136074107315982337",
    "fullText" : "@AndrewYang @scottsantens That’s the kind of open mind we need as #POTUS .  Things change, new better ideas pop up along the way.  Being political is a disservice to s populations’ needs.  Facts, idea, consultation, action, in that order.",
    "expandedUrl" : "https://twitter.com/i/web/status/1136074107315982337"
  }
}, {
  "like" : {
    "tweetId" : "1135905678734893058",
    "fullText" : "Rumor swirling that a big activist has taken a stake in Tesla $TSLA and he/she said it reminds them of $NFLX in 2011\nExplains the almost $3 million of $TSLA Aug $250 calls swept right at the open.\nCould it be Icahn!",
    "expandedUrl" : "https://twitter.com/i/web/status/1135905678734893058"
  }
}, {
  "like" : {
    "tweetId" : "1141765786983378944",
    "fullText" : "Wait..:God needs help eradicating gay marriage?\n\nThis is some of the dumbest shit I’ve ever seen. https://t.co/lJzzueGer0",
    "expandedUrl" : "https://twitter.com/i/web/status/1141765786983378944"
  }
}, {
  "like" : {
    "tweetId" : "1135635056725233666",
    "fullText" : "If you think our institutions are going to rescue us you have not been paying close attention.",
    "expandedUrl" : "https://twitter.com/i/web/status/1135635056725233666"
  }
}, {
  "like" : {
    "tweetId" : "1134938721588060161",
    "fullText" : "@ValueAnalyst1 All of these. Every single one. #noinventory must be all that “no demand” we have here in Chicago https://t.co/3xLBtnb9qz",
    "expandedUrl" : "https://twitter.com/i/web/status/1134938721588060161"
  }
}, {
  "like" : {
    "tweetId" : "1134923325212221440",
    "fullText" : "Dope or Nope for you @teslaownersSV https://t.co/9RuPlhQzzV",
    "expandedUrl" : "https://twitter.com/i/web/status/1134923325212221440"
  }
}, {
  "like" : {
    "tweetId" : "1134896899625013254",
    "fullText" : "It's not too late to send your name to Mars! \uD83E\uDD16 \n\nOur #Mars2020 Rover is gearing up for its seven-month journey to the Red Planet and you can send your name along for the ride. Get your boarding pass: https://t.co/mX7bZ5Ev6g https://t.co/Gs1TwCHJUz",
    "expandedUrl" : "https://twitter.com/i/web/status/1134896899625013254"
  }
}, {
  "like" : {
    "tweetId" : "1134438761092308992",
    "fullText" : "With all these streaming services, why doesn't one of them bring back ROCKY AND BULLWINKLE? Plus Boris and Natasha? \"Must find moose und squirrel.\" Along with Mr. Peabody and his pet boy, Sherman, of course.",
    "expandedUrl" : "https://twitter.com/i/web/status/1134438761092308992"
  }
}, {
  "like" : {
    "tweetId" : "1134355670818443264",
    "fullText" : "5 years from now, Universities will still be relevant, but there will be an army of young people assembling their own individual education system composed of free, top-quality online resources offered by leading experts. A generation of high-tech niche experts",
    "expandedUrl" : "https://twitter.com/i/web/status/1134355670818443264"
  }
}, {
  "like" : {
    "tweetId" : "1134979979840593920",
    "fullText" : "@Downnotout2 @clairlemon That frame is already the default. I'm on your side, I'm suggesting ways to mitigate the damage.",
    "expandedUrl" : "https://twitter.com/i/web/status/1134979979840593920"
  }
}, {
  "like" : {
    "tweetId" : "1135916680691904513",
    "fullText" : "Premier Ford's climate plan is going to cost Ontarians twice as much as our price on pollution. While they choose to fight climate action and make life more expensive, we'll keep fighting climate change and making life more affordable for all Canadians. https://t.co/I2EiR5dGMI",
    "expandedUrl" : "https://twitter.com/i/web/status/1135916680691904513"
  }
}, {
  "like" : {
    "tweetId" : "1134439424807374848",
    "fullText" : "@StephenKing Yes! Need some WABAC Machine in my life",
    "expandedUrl" : "https://twitter.com/i/web/status/1134439424807374848"
  }
}, {
  "like" : {
    "tweetId" : "1134440070038085632",
    "fullText" : "@StephenKing Can we do Pinky and the Brain, too??? https://t.co/JMO7bJWYCv",
    "expandedUrl" : "https://twitter.com/i/web/status/1134440070038085632"
  }
}, {
  "like" : {
    "tweetId" : "1135615899438919680",
    "fullText" : "You would actually be doing something about climate change if deep down you didn’t think you deserved to go extinct.",
    "expandedUrl" : "https://twitter.com/i/web/status/1135615899438919680"
  }
}, {
  "like" : {
    "tweetId" : "1135904743891656705",
    "fullText" : "Money doesn’t solve every problem - but it sure helps with a lot of them.",
    "expandedUrl" : "https://twitter.com/i/web/status/1135904743891656705"
  }
}, {
  "like" : {
    "tweetId" : "1134934258395443200",
    "fullText" : "George Orwell Predicted Cameras Would Watch Us in Our Homes; He Never Imagined We’d Gladly Buy and Install Them Ourselves \n\nhttps://t.co/epaPF48fdM https://t.co/6LMSTuixnV",
    "expandedUrl" : "https://twitter.com/i/web/status/1134934258395443200"
  }
}, {
  "like" : {
    "tweetId" : "1134789193257881601",
    "fullText" : "A key argument in my Quillette essay is that, in terms of moral progress, the low-hanging fruits are running out. \n\nAnd so, in this new century, we can no longer assume that every generation will be mobilised by a great and noble left-wing cause. This is why @Quillette is needed. https://t.co/DasjE1cd91",
    "expandedUrl" : "https://twitter.com/i/web/status/1134789193257881601"
  }
}, {
  "like" : {
    "tweetId" : "1135731447619379200",
    "fullText" : "If I thought things were going to be all right I definitely would not have run for President.",
    "expandedUrl" : "https://twitter.com/i/web/status/1135731447619379200"
  }
}, {
  "like" : {
    "tweetId" : "1134918474042658823",
    "fullText" : "@amyalkon @primalpoly Possible risks from extra terrestrials? Whose pipe you been smoking.",
    "expandedUrl" : "https://twitter.com/i/web/status/1134918474042658823"
  }
}, {
  "like" : {
    "tweetId" : "1134355672101867520",
    "fullText" : "And that's exactly what we need. Now, the biggest challenges here (apart from technical stuff): Self-discipline, project management, fast and continuous learning, cognitive flexibility, collaborative and emotional intelligence.",
    "expandedUrl" : "https://twitter.com/i/web/status/1134355672101867520"
  }
}, {
  "like" : {
    "tweetId" : "1134967258453827584",
    "fullText" : "Wholesome https://t.co/bDKRIRJhOq",
    "expandedUrl" : "https://twitter.com/i/web/status/1134967258453827584"
  }
}, {
  "like" : {
    "tweetId" : "1134942732777115648",
    "fullText" : "It’s the best, most amazing balloon.  No one else could have such a great balloon. https://t.co/ChlQ5p2S1h",
    "expandedUrl" : "https://twitter.com/i/web/status/1134942732777115648"
  }
}, {
  "like" : {
    "tweetId" : "1134446058942148609",
    "fullText" : "@StephenKing Or...... https://t.co/TBWhDBN7MD",
    "expandedUrl" : "https://twitter.com/i/web/status/1134446058942148609"
  }
}, {
  "like" : {
    "tweetId" : "1133776740445237248",
    "fullText" : "Why are so many people against the success of @Tesla and @elonmusk. I don't understand don't you want a better more substainable energy for your childrens future if not your own? Educate yourself before writing a story about something you know nothing about. Ask Tesla owners.",
    "expandedUrl" : "https://twitter.com/i/web/status/1133776740445237248"
  }
}, {
  "like" : {
    "tweetId" : "1134927928586846211",
    "fullText" : "@JPUConn Completely makes sense. I’ve been giving test drives, etc just planting the seeds. Haha",
    "expandedUrl" : "https://twitter.com/i/web/status/1134927928586846211"
  }
}, {
  "like" : {
    "tweetId" : "1133473670968614917",
    "fullText" : "My @Tesla may have saved my life. Thought it would be a boring drive across Nebraska, instead a semi strayed into my lane &amp; I fishtailed into wet grassy median. RWD Model 3 didn't spin or roll over. I was able to get it back on road. Covered in grass, but safe. Thanks @elonmusk https://t.co/i9JRDhJquW",
    "expandedUrl" : "https://twitter.com/i/web/status/1133473670968614917"
  }
}, {
  "like" : {
    "tweetId" : "1135686049076613121",
    "fullText" : "@elonmusk @Teslarati I get your thinking. It's been awesome to see how China had accepted Tesla and how we are moving so fast along. Props to you for tapping the biggest demand region.",
    "expandedUrl" : "https://twitter.com/i/web/status/1135686049076613121"
  }
} ]