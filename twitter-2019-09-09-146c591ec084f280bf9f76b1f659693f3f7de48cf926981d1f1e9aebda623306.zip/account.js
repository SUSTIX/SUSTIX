window.YTD.account.part0 = [ {
  "account" : {
    "email" : "nomomonopolies@gmail.com",
    "createdVia" : "oauth:3033300",
    "username" : "Downnotout2",
    "accountId" : "1134088040538939392",
    "createdAt" : "2019-05-30T13:23:53.988Z",
    "accountDisplayName" : "Confused"
  }
} ]