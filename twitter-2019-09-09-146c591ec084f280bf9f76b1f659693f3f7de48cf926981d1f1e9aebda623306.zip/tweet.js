window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/Yit5WiTGiL",
      "expanded_url" : "http://primalblueprint.libsyn.com/tony-gaskins-jr",
      "display_url" : "primalblueprint.libsyn.com/tony-gaskins-jr",
      "indices" : [ "44", "67" ]
    } ]
  },
  "display_text_range" : [ "0", "67" ],
  "favorite_count" : "0",
  "id_str" : "1171176904113762304",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1171176904113762304",
  "possibly_sensitive" : false,
  "created_at" : "Mon Sep 09 21:41:48 +0000 2019",
  "favorited" : false,
  "full_text" : "Primal Blueprint Podcast: Tony Gaskins, Jr. https://t.co/Yit5WiTGiL",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/rxQNlIOldG",
      "expanded_url" : "https://www.abc.net.au/radionational/programs/allinthemind/inside-talking-therapy/11478090",
      "display_url" : "abc.net.au/radionational/…",
      "indices" : [ "49", "72" ]
    } ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "id_str" : "1170674611241005056",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1170674611241005056",
  "possibly_sensitive" : false,
  "created_at" : "Sun Sep 08 12:25:52 +0000 2019",
  "favorited" : false,
  "full_text" : "All In The Mind - ABC RN: Inside talking therapy https://t.co/rxQNlIOldG",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "World of Engineering",
      "screen_name" : "engineers_feed",
      "indices" : [ "0", "15" ],
      "id_str" : "3429950987",
      "id" : "3429950987"
    }, {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ "16", "25" ],
      "id_str" : "44196397",
      "id" : "44196397"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1170271516161990657",
  "id_str" : "1170369705149980672",
  "in_reply_to_user_id" : "3429950987",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1170369705149980672",
  "in_reply_to_status_id" : "1170271516161990657",
  "created_at" : "Sat Sep 07 16:14:16 +0000 2019",
  "favorited" : false,
  "full_text" : "@engineers_feed @elonmusk seemingly \"good\".\nYou don't want to pick everyone else apart for a \"good\" try.",
  "lang" : "en",
  "in_reply_to_screen_name" : "engineers_feed",
  "in_reply_to_user_id_str" : "3429950987"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/qpVv8IZF2D",
      "expanded_url" : "https://traffic.megaphone.fm/PTB5302130660.mp3",
      "display_url" : "traffic.megaphone.fm/PTB5302130660.…",
      "indices" : [ "62", "85" ]
    } ]
  },
  "display_text_range" : [ "0", "85" ],
  "favorite_count" : "0",
  "id_str" : "1169695966720593921",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169695966720593921",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 05 19:37:05 +0000 2019",
  "favorited" : false,
  "full_text" : "Pick the Brain Podcast: Follow Your Heart - Inspirational Mix https://t.co/qpVv8IZF2D",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/KyHXG8iz6v",
      "expanded_url" : "https://www.richroll.com/podcast/julie-piatt-465/",
      "display_url" : "richroll.com/podcast/julie-…",
      "indices" : [ "56", "79" ]
    } ]
  },
  "display_text_range" : [ "0", "79" ],
  "favorite_count" : "0",
  "id_str" : "1169617921431261184",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169617921431261184",
  "possibly_sensitive" : false,
  "created_at" : "Thu Sep 05 14:26:57 +0000 2019",
  "favorited" : false,
  "full_text" : "Rich Roll » Podcast: Keep Evolving: Julie Piatt Returns https://t.co/KyHXG8iz6v",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/LbZErOsCN9",
      "expanded_url" : "http://mwfmotivation.libsyn.com/whats-your-one-thing",
      "display_url" : "mwfmotivation.libsyn.com/whats-your-one…",
      "indices" : [ "75", "98" ]
    } ]
  },
  "display_text_range" : [ "0", "109" ],
  "favorite_count" : "0",
  "id_str" : "1169252065358635009",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169252065358635009",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 04 14:13:10 +0000 2019",
  "favorited" : false,
  "full_text" : "The Mindset &amp; Motivation Podcast with Rob Dial: What's Your ONE Thing? https://t.co/LbZErOsCN9 [00:29:06]",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ "12", "18" ],
      "id_str" : "33696409",
      "id" : "33696409"
    } ],
    "urls" : [ {
      "url" : "https://t.co/hWaUFAlEPi",
      "expanded_url" : "https://www.quora.com/How-do-we-know-that-were-not-living-in-a-computer-simulation?ch=2&share=68cf7dbe&srid=czh3K",
      "display_url" : "quora.com/How-do-we-know…",
      "indices" : [ "83", "106" ]
    } ]
  },
  "display_text_range" : [ "0", "106" ],
  "favorite_count" : "0",
  "id_str" : "1169062768219250689",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169062768219250689",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 04 01:40:58 +0000 2019",
  "favorited" : false,
  "full_text" : "Question on @Quora: How do we know that we're not living in a computer simulation? https://t.co/hWaUFAlEPi",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ "12", "18" ],
      "id_str" : "33696409",
      "id" : "33696409"
    } ],
    "urls" : [ {
      "url" : "https://t.co/K7IRgS5kqC",
      "expanded_url" : "https://www.quora.com/What-s-a-sign-we-re-living-in-a-simulation?ch=2&share=c16d273b&srid=czh3K",
      "display_url" : "quora.com/What-s-a-sign-…",
      "indices" : [ "64", "87" ]
    } ]
  },
  "display_text_range" : [ "0", "87" ],
  "favorite_count" : "0",
  "id_str" : "1169061611195260929",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169061611195260929",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 04 01:36:22 +0000 2019",
  "favorited" : false,
  "full_text" : "Question on @Quora: What’s a sign we’re living in a simulation? https://t.co/K7IRgS5kqC",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/QagH9snutP",
      "expanded_url" : "https://art19.com/shows/the-art-of-charm",
      "display_url" : "art19.com/shows/the-art-…",
      "indices" : [ "79", "102" ]
    } ]
  },
  "display_text_range" : [ "0", "113" ],
  "favorite_count" : "0",
  "id_str" : "1169039357677907968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1169039357677907968",
  "possibly_sensitive" : false,
  "created_at" : "Wed Sep 04 00:07:57 +0000 2019",
  "favorited" : false,
  "full_text" : "The Art of Charm: 769: Laura Heck: AVOID These 4 Behaviors in Any Relationship https://t.co/QagH9snutP [00:15:49]",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/tEgPSordiV",
      "expanded_url" : "http://primalblueprint.libsyn.com/dude-spellings-part-1-cold-exposure-benefits-and-balancing-training-and-life-stress",
      "display_url" : "primalblueprint.libsyn.com/dude-spellings…",
      "indices" : [ "112", "135" ]
    } ]
  },
  "display_text_range" : [ "0", "135" ],
  "favorite_count" : "0",
  "id_str" : "1168977392548929537",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168977392548929537",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 20:01:43 +0000 2019",
  "favorited" : false,
  "full_text" : "Primal Blueprint Podcast: Dude Spellings, Part 1: Cold Exposure Benefits And Balancing Training And Life Stress https://t.co/tEgPSordiV",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ "0", "13" ],
      "id_str" : "116994659",
      "id" : "116994659"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1168907129824190464",
  "id_str" : "1168974005048684547",
  "in_reply_to_user_id" : "116994659",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168974005048684547",
  "in_reply_to_status_id" : "1168907129824190464",
  "created_at" : "Tue Sep 03 19:48:15 +0000 2019",
  "favorited" : false,
  "full_text" : "@SamHarrisOrg Embodying incentives that a majority of people want.",
  "lang" : "en",
  "in_reply_to_screen_name" : "SamHarrisOrg",
  "in_reply_to_user_id_str" : "116994659"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/dLw2OW3dXm",
      "expanded_url" : "https://idopodcast.com/213",
      "display_url" : "idopodcast.com/213",
      "indices" : [ "74", "97" ]
    } ]
  },
  "display_text_range" : [ "0", "97" ],
  "favorite_count" : "0",
  "id_str" : "1168925711882756101",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168925711882756101",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 16:36:21 +0000 2019",
  "favorited" : false,
  "full_text" : "Relationship Advice: 213: Supporting A Partner Who Is Managing Depression https://t.co/dLw2OW3dXm",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/lUGyq203MU",
      "expanded_url" : "https://anchor.fm/optimal-living-daily/episodes/1361-Living-For-Yourself--Not-Others-by-Aileen-Xu-of-Lavendaire-on-Self-Help--Being-True-to-Yourself-e56jfv",
      "display_url" : "anchor.fm/optimal-living…",
      "indices" : [ "184", "207" ]
    } ]
  },
  "display_text_range" : [ "0", "207" ],
  "favorite_count" : "0",
  "id_str" : "1168917660840681472",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168917660840681472",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 16:04:22 +0000 2019",
  "favorited" : false,
  "full_text" : "Optimal Living Daily: Personal Development &amp; Minimalism: 1361: Living For Yourself &amp; Not Others by Aileen Xu of Lavendaire on Self Help &amp; Being True to Yourself. Be proud. https://t.co/lUGyq203MU",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/2A82FvY7nR",
      "expanded_url" : "http://theatpproject.libsyn.com/autism-understanding-the-spectrum",
      "display_url" : "theatpproject.libsyn.com/autism-underst…",
      "indices" : [ "67", "90" ]
    } ]
  },
  "display_text_range" : [ "0", "90" ],
  "favorite_count" : "0",
  "id_str" : "1168908481509961729",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168908481509961729",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 15:27:53 +0000 2019",
  "favorited" : false,
  "full_text" : "The ATP Project's Podcast: Autism - Understanding the spectrum. 4\uD83D\uDC1D https://t.co/2A82FvY7nR",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/1Jthw10aPO",
      "expanded_url" : "https://elitemanmagazine.com/justin-ehrlich-control-your-mind/",
      "display_url" : "elitemanmagazine.com/justin-ehrlich…",
      "indices" : [ "140", "163" ]
    } ]
  },
  "display_text_range" : [ "0", "163" ],
  "favorite_count" : "0",
  "id_str" : "1168869048534388736",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168869048534388736",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 12:51:12 +0000 2019",
  "favorited" : false,
  "full_text" : "Elite Man Podcast: How To Take Back Control Of Your Mind When Everything Seems Lost – Justin Ehrlich (Ep. 239)\nWhat are my catching points? https://t.co/1Jthw10aPO",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/QaRRA67LWA",
      "expanded_url" : "http://mwfmotivation.libsyn.com/are-you-already-dead-1",
      "display_url" : "mwfmotivation.libsyn.com/are-you-alread…",
      "indices" : [ "97", "120" ]
    } ]
  },
  "display_text_range" : [ "0", "120" ],
  "favorite_count" : "0",
  "id_str" : "1168859717474639873",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168859717474639873",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 12:14:07 +0000 2019",
  "favorited" : false,
  "full_text" : "The Mindset &amp; Motivation Podcast with Rob Dial: Are You Already Dead? Breaking your routine. https://t.co/QaRRA67LWA",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/66d7W52fwl",
      "expanded_url" : "https://art19.com/shows/aubrey-marcus-podcast",
      "display_url" : "art19.com/shows/aubrey-m…",
      "indices" : [ "92", "115" ]
    } ]
  },
  "display_text_range" : [ "0", "115" ],
  "favorite_count" : "0",
  "id_str" : "1168851903104659456",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168851903104659456",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 11:43:04 +0000 2019",
  "favorited" : false,
  "full_text" : "Aubrey Marcus Podcast: AMP Books 2: The Prophet by Kahlil Gibran. Judging ad connectedness. https://t.co/66d7W52fwl",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/YXg1mqwgp3",
      "expanded_url" : "https://kylekingsburypodcast.podbean.com/e/105-max-lugavere/",
      "display_url" : "kylekingsburypodcast.podbean.com/e/105-max-luga…",
      "indices" : [ "127", "150" ]
    } ]
  },
  "display_text_range" : [ "0", "150" ],
  "favorite_count" : "0",
  "id_str" : "1168848607799390208",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168848607799390208",
  "possibly_sensitive" : false,
  "created_at" : "Tue Sep 03 11:29:58 +0000 2019",
  "favorited" : false,
  "full_text" : "Kyle Kingsbury Podcast: #105 Max Lugavere. The chemicals we encounter, links to Alzheimer's, whole foods VS processed. Biases. https://t.co/YXg1mqwgp3",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/i99URTleOh",
      "expanded_url" : "https://soundcloud.com/lewishowes/dr-nicole-lepera",
      "display_url" : "soundcloud.com/lewishowes/dr-…",
      "indices" : [ "104", "127" ]
    } ]
  },
  "display_text_range" : [ "0", "127" ],
  "favorite_count" : "0",
  "id_str" : "1168656811328716800",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1168656811328716800",
  "possibly_sensitive" : false,
  "created_at" : "Mon Sep 02 22:47:51 +0000 2019",
  "favorited" : false,
  "full_text" : "The School of Greatness: Become a Self-Healer and Break Free of Emotional Cycles with Dr. Nicole LePera https://t.co/i99URTleOh",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/YszEzZbNZr",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9mZWVkczIuZmVlZGJ1cm5lci5jb20vdGVkdGFsa3NfYXVkaW8&episode=ZW4uYXVkaW8udGFsay50ZWQuY29tOjQ0Njk2",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1144629957609578503",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1144629957609578503",
  "possibly_sensitive" : false,
  "created_at" : "Fri Jun 28 15:33:42 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/YszEzZbNZr",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/t5QXJGTSu0",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly93d3cubnByLm9yZy9yc3MvcG9kY2FzdC5waHA_aWQ9NTEwMzA4&episode=MTU1ZTRjMTctOWY4Zi00YTlhLWJjZWUtZTVhYWMzMzlhYjI4",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1144628189765001216",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1144628189765001216",
  "possibly_sensitive" : false,
  "created_at" : "Fri Jun 28 15:26:41 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/t5QXJGTSu0",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/elGTjcnhxx",
      "expanded_url" : "https://go.ted.com/CPDF",
      "display_url" : "go.ted.com/CPDF",
      "indices" : [ "81", "104" ]
    } ]
  },
  "display_text_range" : [ "0", "104" ],
  "favorite_count" : "0",
  "id_str" : "1144569858899812352",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1144569858899812352",
  "possibly_sensitive" : false,
  "created_at" : "Fri Jun 28 11:34:54 +0000 2019",
  "favorited" : false,
  "full_text" : "Lynn Rothschild: The living tech we need to support human life on other planets. https://t.co/elGTjcnhxx",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/LTKpPLTiga",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9td2Ztb3RpdmF0aW9uLmxpYnN5bi5jb20vcnNz&episode=MTYxYzAxNzlhYWM3NDBjZTg4YzEzNmVjMmJhOTk0Y2Y",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "21", "44" ]
    } ]
  },
  "display_text_range" : [ "0", "44" ],
  "favorite_count" : "0",
  "id_str" : "1141365400304783360",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1141365400304783360",
  "possibly_sensitive" : false,
  "created_at" : "Wed Jun 19 15:21:31 +0000 2019",
  "favorited" : false,
  "full_text" : "Loving this podcast. https://t.co/LTKpPLTiga",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "43" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1141002683182125056",
  "id_str" : "1141068315059793920",
  "in_reply_to_user_id" : "1134088040538939392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1141068315059793920",
  "in_reply_to_status_id" : "1141002683182125056",
  "created_at" : "Tue Jun 18 19:41:00 +0000 2019",
  "favorited" : false,
  "full_text" : "Because it's better to repair than compare.",
  "lang" : "en",
  "in_reply_to_screen_name" : "Downnotout2",
  "in_reply_to_user_id_str" : "1134088040538939392"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/n86zo2bKtu",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9yc3MuYXJ0MTkuY29tL2FydC1vZi1tYW5saW5lc3M&episode=Z2lkOi8vYXJ0MTktZXBpc29kZS1sb2NhdG9yL1YwL0pGUHhBcnltMExGaGJ2MkUwSjdRcDl2bGJwbkVlcFN5b1lCdlFVWHNzWlU",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1141009704887492608",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1141009704887492608",
  "possibly_sensitive" : false,
  "created_at" : "Tue Jun 18 15:48:07 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/n86zo2bKtu",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/y4d9ro4LNK",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9yc3MuYXJ0MTkuY29tL2FydC1vZi1tYW5saW5lc3M&episode=Z2lkOi8vYXJ0MTktZXBpc29kZS1sb2NhdG9yL1YwL1Rnb2d1NG93Z00zZlVGUC1IbEZwWUUxcWgybExzVW1jbFBlVlFERWM1SVE",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1141009646918000640",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1141009646918000640",
  "possibly_sensitive" : false,
  "created_at" : "Tue Jun 18 15:47:53 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/y4d9ro4LNK",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/CfjeM0cdZ0",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9yc3MuYXJ0MTkuY29tL2FydC1vZi1tYW5saW5lc3M&episode=Z2lkOi8vYXJ0MTktZXBpc29kZS1sb2NhdG9yL1YwLzFOTktxNGM0bDFSdXB5VkJqbXpjWjBmSnlVQ0dKY0VtTHlodUdER0RZUms",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1140988541687795712",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1140988541687795712",
  "possibly_sensitive" : false,
  "created_at" : "Tue Jun 18 14:24:01 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/CfjeM0cdZ0",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/rh4llQcPcZ",
      "expanded_url" : "https://www.google.com/podcasts?feed=aHR0cHM6Ly9yc3MuYXJ0MTkuY29tL2FydC1vZi1tYW5saW5lc3M&episode=Z2lkOi8vYXJ0MTktZXBpc29kZS1sb2NhdG9yL1YwL3pXQ09KMk4zQzVBdTVrWl9abTgxdURWdXJaaThyUUZnSm9MZmtqRnh0ems",
      "display_url" : "google.com/podcasts?feed=…",
      "indices" : [ "0", "23" ]
    } ]
  },
  "display_text_range" : [ "0", "23" ],
  "favorite_count" : "0",
  "id_str" : "1140988444463828993",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1140988444463828993",
  "possibly_sensitive" : false,
  "created_at" : "Tue Jun 18 14:23:38 +0000 2019",
  "favorited" : false,
  "full_text" : "https://t.co/rh4llQcPcZ",
  "lang" : "und"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Alexandria Ocasio-Cortez",
      "screen_name" : "AOC",
      "indices" : [ "3", "7" ],
      "id_str" : "138203134",
      "id" : "138203134"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1140971821115805698",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1140971821115805698",
  "created_at" : "Tue Jun 18 13:17:35 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @AOC: This administration has established concentration camps on the southern border of the United States for immigrants, where they are…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Andrew Yang",
      "screen_name" : "AndrewYang",
      "indices" : [ "3", "14" ],
      "id_str" : "2228878592",
      "id" : "2228878592"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "140" ],
  "favorite_count" : "0",
  "id_str" : "1136197163367768064",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1136197163367768064",
  "created_at" : "Wed Jun 05 09:04:47 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @AndrewYang: Automation and artificial intelligence pose an unprecedented challenge to our current version of capitalism. We must evolve…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/uGGmWd953A",
      "expanded_url" : "https://twitter.com/AM2DM/status/1135914979519913985",
      "display_url" : "twitter.com/AM2DM/status/1…",
      "indices" : [ "281", "304" ]
    } ]
  },
  "display_text_range" : [ "0", "304" ],
  "favorite_count" : "0",
  "id_str" : "1135936228203859968",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1135936228203859968",
  "possibly_sensitive" : false,
  "created_at" : "Tue Jun 04 15:47:56 +0000 2019",
  "favorited" : false,
  "full_text" : "Andrew Yang has quite a few well thought out ideas IMO. I think we need to pay attention. Our future depends on it. We need to anticipate how technology and automation will affect us all in the near, medium, and long term. Change in these areas is coming quicker than we r rdy for https://t.co/uGGmWd953A",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Steve Jobs Ghost \uD83D\uDC7B",
      "screen_name" : "tesla_truth",
      "indices" : [ "0", "12" ],
      "id_str" : "1067553335970955264",
      "id" : "1067553335970955264"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "291" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "1135198603792723969",
  "id_str" : "1135472397849677825",
  "in_reply_to_user_id" : "1067553335970955264",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1135472397849677825",
  "in_reply_to_status_id" : "1135198603792723969",
  "created_at" : "Mon Jun 03 09:04:50 +0000 2019",
  "favorited" : false,
  "full_text" : "@tesla_truth The price of bitcoin seems controlled to me. Similarly to how the prices in the stock market are. I find it discouraging to think that large institutions are buying into crypto and manipulating prices. Especially if the institution know when to jump ship from a failing economy.",
  "lang" : "en",
  "in_reply_to_screen_name" : "tesla_truth",
  "in_reply_to_user_id_str" : "1067553335970955264"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Adam Best",
      "screen_name" : "adamcbest",
      "indices" : [ "3", "13" ],
      "id_str" : "17261066",
      "id" : "17261066"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "139" ],
  "favorite_count" : "0",
  "id_str" : "1134979664269795328",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134979664269795328",
  "created_at" : "Sun Jun 02 00:26:53 +0000 2019",
  "favorited" : false,
  "full_text" : "RT @adamcbest: At Virginia Beach, it took four cops — trained professionals wearing bulletproof vests — using all their ammunition to take…",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "James Tiberius Stone",
      "screen_name" : "Evolving_Ego",
      "indices" : [ "0", "13" ],
      "id_str" : "803285017799499776",
      "id" : "803285017799499776"
    }, {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ "14", "25" ],
      "id_str" : "1398479138",
      "id" : "1398479138"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "134" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "1134978734107320325",
  "id_str" : "1134979496887672832",
  "in_reply_to_user_id" : "1134088040538939392",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134979496887672832",
  "in_reply_to_status_id" : "1134978734107320325",
  "created_at" : "Sun Jun 02 00:26:13 +0000 2019",
  "favorited" : false,
  "full_text" : "@Evolving_Ego @clairlemon I think framing things in the way you have: x vs y, which one are you?\nis not necessary and can be damaging.",
  "lang" : "en",
  "in_reply_to_screen_name" : "Downnotout2",
  "in_reply_to_user_id_str" : "1134088040538939392"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "James Tiberius Stone",
      "screen_name" : "Evolving_Ego",
      "indices" : [ "0", "13" ],
      "id_str" : "803285017799499776",
      "id" : "803285017799499776"
    }, {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ "14", "25" ],
      "id_str" : "1398479138",
      "id" : "1398479138"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "305" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134962542931980288",
  "id_str" : "1134978734107320325",
  "in_reply_to_user_id" : "803285017799499776",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134978734107320325",
  "in_reply_to_status_id" : "1134962542931980288",
  "created_at" : "Sun Jun 02 00:23:11 +0000 2019",
  "favorited" : false,
  "full_text" : "@Evolving_Ego @clairlemon Maybe the problem is ideology/idealism. Tethering everything to it. Progress doesn't work that way. Ideas have their own merrit, so applying anything but full consideration doesn't make sense to me. I don't believe that the answers needed are found in writing from centuries ago.",
  "lang" : "en",
  "in_reply_to_screen_name" : "Evolving_Ego",
  "in_reply_to_user_id_str" : "803285017799499776"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/oAhFSLeU8c",
      "expanded_url" : "https://twitter.com/amyalkon/status/1134930701034434561",
      "display_url" : "twitter.com/amyalkon/statu…",
      "indices" : [ "14", "37" ]
    } ]
  },
  "display_text_range" : [ "0", "37" ],
  "favorite_count" : "0",
  "id_str" : "1134960488092225537",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134960488092225537",
  "possibly_sensitive" : false,
  "created_at" : "Sat Jun 01 23:10:41 +0000 2019",
  "favorited" : false,
  "full_text" : "How true, lol https://t.co/oAhFSLeU8c",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Philippe Lemoine",
      "screen_name" : "phl43",
      "indices" : [ "0", "6" ],
      "id_str" : "850763376263299078",
      "id" : "850763376263299078"
    }, {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ "7", "18" ],
      "id_str" : "1398479138",
      "id" : "1398479138"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "299" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134603481027887104",
  "id_str" : "1134954547665936384",
  "in_reply_to_user_id" : "850763376263299078",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134954547665936384",
  "in_reply_to_status_id" : "1134603481027887104",
  "created_at" : "Sat Jun 01 22:47:05 +0000 2019",
  "favorited" : false,
  "full_text" : "@phl43 @clairlemon My SO plays video games whenever she has a chance. I grew out of them, but love to play multiplayer with my kids, because there are thousands of skills you can learn from mastering certain video games, and we have an amazing time. Patience, practice, progress, teamwork,p. solving",
  "lang" : "en",
  "in_reply_to_screen_name" : "phl43",
  "in_reply_to_user_id_str" : "850763376263299078"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Rob Hoehn",
      "screen_name" : "rhoehn",
      "indices" : [ "0", "7" ],
      "id_str" : "14719012",
      "id" : "14719012"
    }, {
      "name" : "Tesla Owners Silicon Valley",
      "screen_name" : "teslaownersSV",
      "indices" : [ "8", "22" ],
      "id_str" : "1016059981907386368",
      "id" : "1016059981907386368"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "46" ],
  "favorite_count" : "3",
  "in_reply_to_status_id_str" : "1134923325212221440",
  "id_str" : "1134940346910171136",
  "in_reply_to_user_id" : "14719012",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134940346910171136",
  "in_reply_to_status_id" : "1134923325212221440",
  "created_at" : "Sat Jun 01 21:50:39 +0000 2019",
  "favorited" : false,
  "full_text" : "@rhoehn @teslaownersSV Love how it stands out.",
  "lang" : "en",
  "in_reply_to_screen_name" : "rhoehn",
  "in_reply_to_user_id_str" : "14719012"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Helen Joyce",
      "screen_name" : "HJJoyceEcon",
      "indices" : [ "0", "12" ],
      "id_str" : "1110105054",
      "id" : "1110105054"
    }, {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ "13", "24" ],
      "id_str" : "1398479138",
      "id" : "1398479138"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "83" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134744969170829312",
  "id_str" : "1134938931806580736",
  "in_reply_to_user_id" : "1110105054",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134938931806580736",
  "in_reply_to_status_id" : "1134744969170829312",
  "created_at" : "Sat Jun 01 21:45:02 +0000 2019",
  "favorited" : false,
  "full_text" : "@HJJoyceEcon @clairlemon I'm against pieces of paper that define almost everything.",
  "lang" : "en",
  "in_reply_to_screen_name" : "HJJoyceEcon",
  "in_reply_to_user_id_str" : "1110105054"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Helen Joyce",
      "screen_name" : "HJJoyceEcon",
      "indices" : [ "0", "12" ],
      "id_str" : "1110105054",
      "id" : "1110105054"
    }, {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ "13", "24" ],
      "id_str" : "1398479138",
      "id" : "1398479138"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "290" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134744969170829312",
  "id_str" : "1134938236567117824",
  "in_reply_to_user_id" : "1110105054",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134938236567117824",
  "in_reply_to_status_id" : "1134744969170829312",
  "created_at" : "Sat Jun 01 21:42:16 +0000 2019",
  "favorited" : false,
  "full_text" : "@HJJoyceEcon @clairlemon Everything in this capitalist society seems to want to draw you deeper into its clutches. Why participate in the largest online social community where you have responsibility and have fun playing strategy games? I Love cramming and not be told exactly how to learn.",
  "lang" : "en",
  "in_reply_to_screen_name" : "HJJoyceEcon",
  "in_reply_to_user_id_str" : "1110105054"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Muddy Schmuck \uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDF9\uD83C\uDDFC\uD83C\uDDED\uD83C\uDDF0\uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "TheMuddySchmuck",
      "indices" : [ "0", "16" ],
      "id_str" : "20160570",
      "id" : "20160570"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "64" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134566935109050368",
  "id_str" : "1134934334975172610",
  "in_reply_to_user_id" : "20160570",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134934334975172610",
  "in_reply_to_status_id" : "1134566935109050368",
  "created_at" : "Sat Jun 01 21:26:46 +0000 2019",
  "favorited" : false,
  "full_text" : "@TheMuddySchmuck Agree, more should get on board. Whale hunting.",
  "lang" : "en",
  "in_reply_to_screen_name" : "TheMuddySchmuck",
  "in_reply_to_user_id_str" : "20160570"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Quillette",
      "screen_name" : "Quillette",
      "indices" : [ "0", "10" ],
      "id_str" : "3775360879",
      "id" : "3775360879"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "72" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1134867295052992517",
  "id_str" : "1134933214534033408",
  "in_reply_to_user_id" : "3775360879",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134933214534033408",
  "in_reply_to_status_id" : "1134867295052992517",
  "created_at" : "Sat Jun 01 21:22:19 +0000 2019",
  "favorited" : false,
  "full_text" : "@Quillette Who said you choose your gender? Your born with your Gen.....",
  "lang" : "en",
  "in_reply_to_screen_name" : "Quillette",
  "in_reply_to_user_id_str" : "3775360879"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ {
      "url" : "https://t.co/qSe0aSXiik",
      "expanded_url" : "https://twitter.com/Quillette/status/1134927738438115334",
      "display_url" : "twitter.com/Quillette/stat…",
      "indices" : [ "132", "155" ]
    } ]
  },
  "display_text_range" : [ "0", "155" ],
  "favorite_count" : "0",
  "id_str" : "1134930063684710404",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134930063684710404",
  "possibly_sensitive" : false,
  "created_at" : "Sat Jun 01 21:09:47 +0000 2019",
  "favorited" : false,
  "full_text" : "The world is filled with enough hot air as it is, don't you think? Sad world where people get ahead by throwing others under buses. https://t.co/qSe0aSXiik",
  "lang" : "en"
}, {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Derek Hopper",
      "screen_name" : "DerekJHopper1",
      "indices" : [ "0", "14" ],
      "id_str" : "814664978573602816",
      "id" : "814664978573602816"
    }, {
      "name" : "Suzana Ilić",
      "screen_name" : "suzatweet",
      "indices" : [ "15", "25" ],
      "id_str" : "94199200",
      "id" : "94199200"
    } ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "66" ],
  "favorite_count" : "1",
  "in_reply_to_status_id_str" : "1134617203817377793",
  "id_str" : "1134927708033605632",
  "in_reply_to_user_id" : "814664978573602816",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1134927708033605632",
  "in_reply_to_status_id" : "1134617203817377793",
  "created_at" : "Sat Jun 01 21:00:26 +0000 2019",
  "favorited" : false,
  "full_text" : "@DerekJHopper1 @suzatweet It takes a team to build something great",
  "lang" : "en",
  "in_reply_to_screen_name" : "DerekJHopper1",
  "in_reply_to_user_id_str" : "814664978573602816"
} ]